import * as THREE from 'three';

/* ============================================================
   GUNBATTE BALLS — Koholint Island  (demo v2, AAA pass)
   Toy-diorama marble shooter: power seeds, streaks, danger mode,
   living island, procedural music. One level, launch-ready demo.
   "Ganbatte" = do your best!
   ============================================================ */

const BALL_R = 0.55, SPACING = 1.14;
const TOTAL_BALLS = 40, COLORS_N = 4;
const DIFFS = { chill: 0.68, normal: 1.0, spicy: 1.28 };
const PALETTE = [0xe63946, 0x4361ee, 0x2dc653, 0xffc700];
const PALETTE_CSS = ['#e63946', '#4361ee', '#2dc653', '#ffc700'];
const POWERS = {
  bomb: { letter: 'B', bg: '#2b2d42', name: 'BOOMSEED' },
  slow: { letter: 'S', bg: '#4361ee', name: 'CHILLSEED' },
  rev:  { letter: 'R', bg: '#9d4edd', name: 'REWINDSEED' },
};
const SHOOTER_POS = new THREE.Vector3(0, 0.6, 1.0);
const baseSpeed = () => (0.95 + 0.4 * (G.spawned / TOTAL_BALLS)) * (DIFFS[G.diff] || 1);

/* ==================== AUDIO (all procedural) ==================== */
let AC = null, master = null, noiseBuf = null;
function audio() {
  if (AC) return true;
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    master = AC.createGain(); master.gain.value = G.muted ? 0 : 1;
    master.connect(AC.destination);
    noiseBuf = AC.createBuffer(1, AC.sampleRate * 0.5, AC.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return true;
  } catch { return false; }
}
function tone(f0, f1, dur, type = 'sine', vol = 0.12, when = 0) {
  if (!AC || G.muted) return;
  const t = AC.currentTime + when;
  const o = AC.createOscillator(), g = AC.createGain();
  o.type = type; o.frequency.setValueAtTime(Math.max(30, f0), t);
  if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.03);
}
function noise(dur = 0.4, vol = 0.25, freq = 800, when = 0) {
  if (!AC || G.muted) return;
  const t = AC.currentTime + when;
  const s = AC.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
  const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq;
  const g = AC.createGain();
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  s.connect(f); f.connect(g); g.connect(master); s.start(t); s.stop(t + dur + 0.03);
}
function sfx(kind) {
  if (G.sim || G.muted || !audio()) return;
  if (AC.state === 'suspended') AC.resume();
  const N = { C5: 72, D5: 74, E5: 76, G5: 79, A5: 81, C6: 84 };
  const mf = m => 440 * Math.pow(2, (m - 69) / 12);
  switch (kind) {
    case 'shoot': tone(700, 220, 0.12, 'square', 0.07); break;
    case 'pop': tone(520, 940, 0.14, 'sine', 0.12); tone(780, 1400, 0.1, 'sine', 0.06, 0.03); break;
    case 'big': tone(300, 1200, 0.28, 'sawtooth', 0.09); noise(0.2, 0.1, 2000); break;
    case 'bomb': noise(0.5, 0.3, 500); tone(140, 32, 0.5, 'sawtooth', 0.2); break;
    case 'power': [76, 79, 81, 84].forEach((m, i) => tone(mf(m), mf(m), 0.12, 'triangle', 0.1, i * 0.06)); break;
    case 'swap': tone(600, 800, 0.07, 'sine', 0.07); break;
    case 'warn': tone(70, 55, 0.25, 'sine', 0.22); tone(70, 55, 0.25, 'sine', 0.22, 0.3); break;
    case 'heart': tone(65, 50, 0.16, 'sine', 0.2); tone(60, 48, 0.14, 'sine', 0.16, 0.18); break;
    case 'win': [72, 76, 79, 84, 88].forEach((m, i) => tone(mf(m), mf(m), 0.22, 'triangle', 0.12, i * 0.11)); break;
    case 'lose': [67, 64, 60, 55].forEach((m, i) => tone(mf(m), mf(m) * 0.97, 0.3, 'sawtooth', 0.08, i * 0.18)); break;
    case 'click': tone(880, 880, 0.05, 'square', 0.05); break;
  }
}
/* tiny island BGM: plucked pentatonic loop + bass */
const Music = {
  on: false, step: 0, nextT: 0,
  mel: [72,76,79,76, 81,79,76,74, 72,76,79,81, 79,76,74,72,
        72,76,79,76, 81,84,81,79, 76,79,76,74, 72,0,76,0],
  roots: [36, 43, 45, 41],
  start() { if (!audio()) return; this.on = true; this.step = 0; this.nextT = AC.currentTime + 0.1; },
  tick() {
    if (!this.on || !AC || G.muted || AC.state !== 'running') return;
    if (G.status !== 'playing' && G.status !== 'intro') return;
    const mf = m => 440 * Math.pow(2, (m - 69) / 12);
    while (this.nextT < AC.currentTime + 0.35) {
      const dt = Math.max(0, this.nextT - AC.currentTime);
      const m = this.mel[this.step % 32];
      if (m) {
        const o = AC.createOscillator(), g = AC.createGain();
        o.type = 'triangle'; o.frequency.value = mf(m);
        g.gain.setValueAtTime(0.045, AC.currentTime + dt);
        g.gain.exponentialRampToValueAtTime(0.001, AC.currentTime + dt + 0.19);
        o.connect(g); g.connect(master); o.start(AC.currentTime + dt); o.stop(AC.currentTime + dt + 0.22);
      }
      if (this.step % 4 === 0) {
        const r = this.roots[((this.step / 4) | 0) % 4];
        const o = AC.createOscillator(), g = AC.createGain();
        o.type = 'sine'; o.frequency.value = mf(r);
        g.gain.setValueAtTime(0.055, AC.currentTime + dt);
        g.gain.exponentialRampToValueAtTime(0.001, AC.currentTime + dt + 0.3);
        o.connect(g); g.connect(master); o.start(AC.currentTime + dt); o.stop(AC.currentTime + dt + 0.32);
      }
      this.nextT += 0.21; this.step++;
    }
  },
};

/* ==================== RENDERER / SCENE ==================== */
const canvas = document.getElementById('scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.25;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8fd3ef);
scene.fog = new THREE.Fog(0x9fd8ef, 48, 110);

const camera = new THREE.PerspectiveCamera(42, innerWidth / innerHeight, 0.1, 400);
camera.position.set(0, 29, 21);
camera.lookAt(0, 0, 1.0);

scene.add(new THREE.HemisphereLight(0xeafcff, 0x5a8f4a, 0.95));
const sun = new THREE.DirectionalLight(0xfff4d6, 2.0);
sun.position.set(14, 24, 10);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -20; sun.shadow.camera.right = 20;
sun.shadow.camera.top = 20; sun.shadow.camera.bottom = -20;
sun.shadow.bias = -0.0001; sun.shadow.normalBias = 0.6;
scene.add(sun);
const fill = new THREE.DirectionalLight(0xbde0fe, 0.5);
fill.position.set(-12, 10, -8);
scene.add(fill);

/* ---- gradient sky dome + sun disc ---- */
{
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: {},
    vertexShader: `varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader: `varying vec3 vP;
      void main(){ float h=normalize(vP).y;
        vec3 zen=vec3(0.24,0.5,0.85), mid=vec3(0.56,0.83,0.94), hor=vec3(0.92,0.97,0.93);
        vec3 c = h>0.25 ? mix(mid,zen,smoothstep(0.25,0.9,h)) : mix(hor,mid,smoothstep(-0.08,0.25,h));
        gl_FragColor=vec4(c,1.0); }`,
  });
  scene.add(new THREE.Mesh(new THREE.SphereGeometry(170, 24, 16), skyMat));
  const sunDisc = new THREE.Mesh(new THREE.CircleGeometry(7, 32),
    new THREE.MeshBasicMaterial({ color: 0xfff6c9, fog: false }));
  sunDisc.position.set(-55, 42, -120); sunDisc.lookAt(0, 10, 0);
  scene.add(sunDisc);
  const glow = new THREE.Mesh(new THREE.CircleGeometry(13, 32),
    new THREE.MeshBasicMaterial({ color: 0xfff6c9, transparent: true, opacity: 0.35, fog: false }));
  glow.position.copy(sunDisc.position).add(new THREE.Vector3(0, 0, -0.5)); glow.lookAt(0, 10, 0);
  scene.add(glow);
}

/* ---- animated stylized water ---- */
let waterMesh, waterBase;
{
  const g = new THREE.PlaneGeometry(190, 190, 46, 46);
  waterMesh = new THREE.Mesh(g, new THREE.MeshStandardMaterial({
    color: 0x27a3d3, roughness: 0.45, metalness: 0.05, flatShading: true,
  }));
  waterMesh.rotation.x = -Math.PI / 2; waterMesh.position.y = -1.65;
  waterMesh.receiveShadow = true;
  scene.add(waterMesh);
  waterBase = g.attributes.position.array.slice();
  const foam1 = new THREE.Mesh(new THREE.TorusGeometry(14.6, 0.55, 12, 64),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 }));
  foam1.rotation.x = Math.PI / 2; foam1.position.y = -1.35; foam1.name = 'foam1';
  scene.add(foam1);
  const foam2 = new THREE.Mesh(new THREE.TorusGeometry(16.2, 0.32, 10, 64),
    new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, roughness: 0.7 }));
  foam2.rotation.x = Math.PI / 2; foam2.position.y = -1.45; foam2.name = 'foam2';
  scene.add(foam2);
}

/* ---- island diorama base (open-ended side: no z-fighting) ---- */
const island = new THREE.Group(); scene.add(island);
{
  const side = new THREE.Mesh(
    new THREE.CylinderGeometry(14.2, 11.5, 3.2, 48, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x9c6b3c, roughness: 0.9, side: THREE.DoubleSide })
  );
  side.position.y = -1.02; side.receiveShadow = true; side.castShadow = true;
  island.add(side);
  const top = new THREE.Mesh(
    new THREE.CylinderGeometry(14.2, 14.2, 0.5, 48),
    new THREE.MeshStandardMaterial({ color: 0x71cf5e, roughness: 0.85 })
  );
  top.position.y = 0.35; top.receiveShadow = true;
  island.add(top);
  const patchMat = new THREE.MeshStandardMaterial({ color: 0x5cb84a, roughness: 1 });
  const patchMat2 = new THREE.MeshStandardMaterial({ color: 0x8fe07a, roughness: 1 });
  [[-6,-4,3.2],[6,-4.5,2.6],[-3,6.5,2.8],[7,5.5,2.2],[0,-5.5,2.0],[-10,3,2.0],[11,0,1.8]]
    .forEach(([x, z, r], i) => {
      const p = new THREE.Mesh(new THREE.CircleGeometry(r, 24), i % 2 ? patchMat2 : patchMat);
      p.rotation.x = -Math.PI / 2; p.position.set(x, 0.64, z); p.receiveShadow = true;
      island.add(p);
    });
  const rim = new THREE.Mesh(new THREE.TorusGeometry(13.55, 0.7, 10, 64),
    new THREE.MeshStandardMaterial({ color: 0xf2dfa8, roughness: 0.9 }));
  rim.rotation.x = Math.PI / 2; rim.position.y = 0.35; rim.receiveShadow = true;
  island.add(rim);
}

/* ---- marble path ---- */
const pathPts2D = [
  [-12.2, -7.4], [-10, -8.2], [-5, -8.0], [0, -8.2], [5, -7.8], [9.0, -7.4],
  [11.0, -5.6], [10.6, -3.8], [8.5, -2.5], [5, -2.2], [0, -2.4], [-5, -2.0], [-9, -2.4],
  [-11.0, -0.8], [-10.5, 1.2], [-8.0, 2.9], [-4, 3.7], [0.5, 3.9], [5, 3.5], [8.5, 3.9],
  [10.2, 5.2], [9.9, 6.8], [9.4, 7.8],
];
const curve = new THREE.CatmullRomCurve3(
  pathPts2D.map(([x, z]) => new THREE.Vector3(x, 0.6, z)), false, 'catmullrom', 0.35);
const curveLen = curve.getLength();
{
  const tube = new THREE.TubeGeometry(curve, 220, 1.0, 12, false);
  tube.scale(1, 0.35, 1); tube.computeVertexNormals();
  const road = new THREE.Mesh(tube, new THREE.MeshStandardMaterial({ color: 0xe8c07a, roughness: 0.95 }));
  road.position.y = 0.15; road.receiveShadow = true;
  scene.add(road);
  const tube2 = new THREE.TubeGeometry(curve, 220, 0.62, 12, false);
  tube2.scale(1, 0.35, 1); tube2.computeVertexNormals();
  const inner = new THREE.Mesh(tube2, new THREE.MeshStandardMaterial({ color: 0xf0d090, roughness: 1 }));
  inner.position.y = 0.42; inner.receiveShadow = true;
  scene.add(inner);
  const start = curve.getPointAt(0);
  const portal = new THREE.Group();
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x7d8597, roughness: 0.8, flatShading: true });
  const m1 = new THREE.Mesh(new THREE.DodecahedronGeometry(1.6), rockMat);
  m1.position.set(-0.9, 1.0, 0); m1.castShadow = true;
  const m2 = new THREE.Mesh(new THREE.DodecahedronGeometry(1.6), rockMat);
  m2.position.set(0.9, 1.0, 0); m2.castShadow = true;
  const mtop = new THREE.Mesh(new THREE.DodecahedronGeometry(1.7), rockMat);
  mtop.position.set(0, 2.2, 0); mtop.castShadow = true;
  const hole = new THREE.Mesh(new THREE.CircleGeometry(1.0, 24),
    new THREE.MeshBasicMaterial({ color: 0x14101f }));
  hole.position.set(0, 0.9, 0.9);
  portal.add(m1, m2, mtop, hole);
  portal.position.copy(start).add(new THREE.Vector3(-0.6, 0, 0));
  portal.rotation.y = Math.PI / 2.3;
  scene.add(portal);
}

/* ---- skull cave (glowing eyes, teeth, smoke) ---- */
const skullPos = curve.getPointAt(1);
let skullEyeMat, skullMouth;
{
  const g = new THREE.Group();
  const stone = new THREE.MeshStandardMaterial({ color: 0x8d99ae, roughness: 0.85, flatShading: true });
  const hill = new THREE.Mesh(new THREE.ConeGeometry(3.2, 4.5, 7), stone);
  hill.position.y = 2.0; hill.castShadow = true; hill.receiveShadow = true;
  g.add(hill);
  skullMouth = new THREE.Mesh(new THREE.CircleGeometry(1.25, 24),
    new THREE.MeshBasicMaterial({ color: 0x0d0a1a }));
  skullMouth.position.set(0, 1.0, 2.35);
  g.add(skullMouth);
  for (let i = -1; i <= 1; i++) {
    const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.5, 5),
      new THREE.MeshStandardMaterial({ color: 0xf8f3df, roughness: 0.6 }));
    tooth.position.set(i * 0.55, 0.35, 2.4); tooth.rotation.x = Math.PI;
    g.add(tooth);
  }
  const skull = new THREE.Mesh(new THREE.SphereGeometry(1.15, 20, 16),
    new THREE.MeshStandardMaterial({ color: 0xf8f3df, roughness: 0.5 }));
  skull.position.set(0, 3.6, 1.4); skull.scale.set(1, 0.9, 0.8); skull.castShadow = true;
  g.add(skull);
  skullEyeMat = new THREE.MeshStandardMaterial({
    color: 0x3a0d0d, emissive: 0xff2200, emissiveIntensity: 0.35, roughness: 0.3 });
  [-0.45, 0.45].forEach(x => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 10), skullEyeMat);
    e.position.set(x, 3.7, 2.15); g.add(e);
  });
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.3, 4),
    new THREE.MeshBasicMaterial({ color: 0x1a1a2e }));
  nose.position.set(0, 3.35, 2.2); nose.rotation.x = Math.PI; g.add(nose);
  g.position.copy(skullPos).add(new THREE.Vector3(0.4, 0, 0.5));
  g.rotation.y = -0.7;
  scene.add(g);
}
const smokes = [];
{
  const sm = new THREE.MeshBasicMaterial({ color: 0x555566, transparent: true, opacity: 0.35 });
  for (let i = 0; i < 5; i++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 6), sm.clone());
    s.position.copy(skullPos).add(new THREE.Vector3(0.4 + Math.random(), 4.5 + i * 0.7, 0.5));
    s.userData.t = Math.random() * 3;
    smokes.push(s); scene.add(s);
  }
}

/* ---- Wind Fish egg shrine (hidden on the beach — a tiny homage) ---- */
{
  const shrine = new THREE.Group();
  const nest = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.28, 10, 18),
    new THREE.MeshStandardMaterial({ color: 0x8d99ae, roughness: 0.9, flatShading: true }));
  nest.rotation.x = Math.PI / 2; nest.position.y = 0.25; nest.castShadow = true;
  shrine.add(nest);
  const egg = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 12),
    new THREE.MeshStandardMaterial({ color: 0xfdf6e3, roughness: 0.5 }));
  egg.scale.set(1, 1.3, 1); egg.position.y = 0.65; egg.castShadow = true;
  shrine.add(egg);
  const spotM = new THREE.MeshStandardMaterial({ color: 0x9d4edd, roughness: 0.7 });
  [[0.2, 0.7, 0.3], [-0.25, 0.55, 0.28], [0, 0.9, -0.3]].forEach(([ox, oy, oz]) => {
    const d = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), spotM);
    d.position.set(ox, oy, oz); shrine.add(d);
  });
  shrine.position.set(12.3, 0.6, -1.5);
  shrine.rotation.y = -0.5;
  scene.add(shrine);
}

/* ---- toy decorations ---- */
function chibiTree(x, z, s = 1) {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.28 * s, 0.36 * s, 1.0 * s, 8),
    new THREE.MeshStandardMaterial({ color: 0x7f4f24, roughness: 0.9 }));
  trunk.position.y = 0.5 * s; trunk.castShadow = true;
  g.add(trunk);
  const greens = [0x2d6a4f, 0x40916c, 0x52b788];
  [[0, 1.5, 0, 0.95], [-0.4, 1.15, 0.15, 0.6], [0.42, 1.2, -0.1, 0.62]].forEach(([ox, oy, oz, r], i) => {
    const f = new THREE.Mesh(new THREE.IcosahedronGeometry(r * s, 1),
      new THREE.MeshStandardMaterial({ color: greens[i % 3], roughness: 0.7, flatShading: true }));
    f.position.set(ox * s, oy * s, oz * s); f.castShadow = true;
    g.add(f);
  });
  g.position.set(x, 0.5, z);
  g.rotation.y = Math.random() * 6;
  scene.add(g);
}
function rock(x, z, s = 1) {
  const m = new THREE.Mesh(new THREE.DodecahedronGeometry(0.5 * s),
    new THREE.MeshStandardMaterial({ color: 0xadb5bd, roughness: 0.85, flatShading: true }));
  m.position.set(x, 0.75, z); m.castShadow = true; m.rotation.set(Math.random(), Math.random() * 3, 0);
  scene.add(m);
}
function flower(x, z, c) {
  const g = new THREE.Group();
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.5, 6),
    new THREE.MeshStandardMaterial({ color: 0x2d6a4f }));
  stem.position.y = 0.25; g.add(stem);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8),
    new THREE.MeshStandardMaterial({ color: c, roughness: 0.4 }));
  head.position.y = 0.55; head.castShadow = true;
  head.name = 'bloom';
  g.add(head);
  g.position.set(x, 0.55, z); scene.add(g);
}
function grassTuft(x, z) {
  const g = new THREE.Group();
  for (let i = 0; i < 3; i++) {
    const b = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.45, 5),
      new THREE.MeshStandardMaterial({ color: 0x3a9e4f, roughness: 1 }));
    b.position.set((i - 1) * 0.12, 0.2, (Math.random() - 0.5) * 0.1);
    b.rotation.z = (i - 1) * 0.25; g.add(b);
  }
  g.position.set(x, 0.55, z); scene.add(g);
}
const pinwheels = [];
function pinwheel(x, z, c) {
  const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.6, 6),
    new THREE.MeshStandardMaterial({ color: 0x8a5a33 }));
  pole.position.y = 0.8; pole.castShadow = true; g.add(pole);
  const hub = new THREE.Group(); hub.position.y = 1.65;
  for (let i = 0; i < 4; i++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.04),
      new THREE.MeshStandardMaterial({ color: i % 2 ? 0xffffff : c, roughness: 0.5 }));
    blade.position.set(Math.cos(i * Math.PI / 2) * 0.3, Math.sin(i * Math.PI / 2) * 0.3, 0);
    blade.rotation.z = i * Math.PI / 2 + 0.5;
    hub.add(blade);
  }
  g.add(hub); pinwheels.push(hub);
  g.position.set(x, 0.55, z); g.rotation.y = 0.6;
  scene.add(g);
}
function nearPath(x, z, d = 1.9) {
  for (let i = 0; i <= 40; i++) {
    const p = curve.getPointAt(i / 40);
    if ((p.x - x) ** 2 + (p.z - z) ** 2 < d * d) return true;
  }
  if ((x - SHOOTER_POS.x) ** 2 + (z - SHOOTER_POS.z) ** 2 < 9) return true;
  if ((x - 9.8) ** 2 + (z - 8.3) ** 2 < 12) return true;
  if ((x + 12.2) ** 2 + (z + 7.4) ** 2 < 9) return true;
  if ((x - 12.3) ** 2 + (z + 1.5) ** 2 < 4) return true; // egg shrine
  return false;
}
{
  let placed = 0, guard = 0;
  while (placed < 22 && guard++ < 500) {
    const a = Math.random() * Math.PI * 2, r = 3 + Math.random() * 10;
    const x = Math.cos(a) * r, z = Math.sin(a) * r * 0.95;
    if (nearPath(x, z)) continue;
    chibiTree(x, z, 0.8 + Math.random() * 0.7); placed++;
  }
  for (let i = 0; i < 12; i++) {
    const a = Math.random() * 6.28, r = 4 + Math.random() * 9;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (nearPath(x, z, 1.4)) continue;
    rock(x, z, 0.7 + Math.random() * 0.9);
  }
  const fc = [0xff5d8f, 0xffca3a, 0xff595e, 0xffffff, 0xc77dff];
  for (let i = 0; i < 26; i++) {
    const a = Math.random() * 6.28, r = 2.5 + Math.random() * 10.5;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (nearPath(x, z, 1.2)) continue;
    flower(x, z, fc[i % fc.length]);
  }
  for (let i = 0; i < 40; i++) {
    const a = Math.random() * 6.28, r = 2 + Math.random() * 11;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (nearPath(x, z, 1.0)) continue;
    grassTuft(x, z);
  }
  const house = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.6, 2.2),
    new THREE.MeshStandardMaterial({ color: 0xfff3d6, roughness: 0.8 }));
  base.position.y = 0.8; base.castShadow = true; house.add(base);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(2.3, 1.4, 4),
    new THREE.MeshStandardMaterial({ color: 0xd62828, roughness: 0.6, flatShading: true }));
  roof.position.y = 2.3; roof.rotation.y = Math.PI / 4; roof.castShadow = true; house.add(roof);
  const door = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 1.0),
    new THREE.MeshStandardMaterial({ color: 0x6c584c }));
  door.position.set(0, 0.6, 1.12); house.add(door);
  const winGlow = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.5),
    new THREE.MeshBasicMaterial({ color: 0xffd166 }));
  winGlow.position.set(0.8, 1.0, 1.12); house.add(winGlow);
  house.position.set(-4.5, 0.5, 8.6); house.rotation.y = 0.4;
  scene.add(house);
  // torch with flickering light
  const torch = new THREE.Group();
  const tpole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 1.8, 8),
    new THREE.MeshStandardMaterial({ color: 0x5c3a1e, roughness: 0.9 }));
  tpole.position.y = 0.9; tpole.castShadow = true; torch.add(tpole);
  const flame = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.7, 8),
    new THREE.MeshBasicMaterial({ color: 0xff7b00 }));
  flame.position.y = 2.0; flame.name = 'flame'; torch.add(flame);
  const core = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.4, 8),
    new THREE.MeshBasicMaterial({ color: 0xffe66d }));
  core.position.y = 1.95; torch.add(core);
  const tl = new THREE.PointLight(0xff9d3c, 6, 11, 1.6);
  tl.position.y = 2.1; tl.name = 'torchlight'; torch.add(tl);
  torch.position.set(-1.8, 0.5, 7.4);
  scene.add(torch);
  pinwheel(6.5, -5.3, 0xe63946);
  pinwheel(-8.5, 6.8, 0x4361ee);
}
/* clouds anchored at frame edges (parallax puffs, never cover play) */
const clouds = [];
{
  const cm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 });
  const spots = [[-12.5, 11, 0], [12.5, 11.5, 1], [-11.5, 12, -7], [11.5, 12.5, -8]];
  spots.forEach(([cx, cy, cz], i) => {
    const g = new THREE.Group();
    for (let j = 0; j < 4; j++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.9 + ((i + j) % 3) * 0.35, 12, 10), cm);
      s.position.set(j * 1.1 - 1.5, ((i * 7 + j * 3) % 5) * 0.12, ((i + j) % 3) * 0.3);
      s.scale.y = 0.7; g.add(s);
    }
    g.position.set(cx, cy, cz);
    clouds.push({ g, y0: cy, ph: i * 1.7 });
    scene.add(g);
  });
}
/* butterflies */
const butterflies = [];
{
  const cols = [0xff9e00, 0xc77dff, 0x90e0ef];
  for (let i = 0; i < 3; i++) {
    const g = new THREE.Group();
    const wm = new THREE.MeshBasicMaterial({ color: cols[i], side: THREE.DoubleSide });
    const wgL = new THREE.PlaneGeometry(0.35, 0.28); wgL.translate(0.17, 0, 0);
    const wgR = new THREE.PlaneGeometry(0.35, 0.28); wgR.translate(-0.17, 0, 0);
    const L = new THREE.Mesh(wgL, wm), R = new THREE.Mesh(wgR, wm);
    g.add(L, R);
    g.position.set((Math.random() - 0.5) * 10, 2.5, (Math.random() - 0.5) * 8);
    butterflies.push({ g, L, R, ph: Math.random() * 9, cx: g.position.x, cz: g.position.z });
    scene.add(g);
  }
}

/* ==================== TARSIUS SHOOTER ==================== */
const tarsius = new THREE.Group();
let muzzle, tarsiusBody, eyeL, eyeR, tailMesh, flashMesh;
{
  const stump = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.7, 0.8, 16),
    new THREE.MeshStandardMaterial({ color: 0x8a5a33, roughness: 0.9 }));
  stump.position.y = 0.4; stump.castShadow = true; stump.receiveShadow = true;
  tarsius.add(stump);
  const ring = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.12, 16),
    new THREE.MeshStandardMaterial({ color: 0xd9a75f, roughness: 0.9 }));
  ring.position.y = 0.82; ring.receiveShadow = true;
  tarsius.add(ring);

  tarsiusBody = new THREE.Group(); tarsiusBody.position.y = 1.0; tarsius.add(tarsiusBody);
  const fur = new THREE.MeshStandardMaterial({ color: 0xb07a45, roughness: 0.8 });
  const bellyM = new THREE.MeshStandardMaterial({ color: 0xf3ddad, roughness: 0.9 });
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.85, 24, 18), fur);
  body.scale.set(1, 1.15, 0.9); body.castShadow = true;
  tarsiusBody.add(body);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.6, 18, 14), bellyM);
  belly.position.set(0, -0.15, 0.45); belly.scale.set(0.8, 1.0, 0.55);
  tarsiusBody.add(belly);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.72, 24, 18), fur);
  head.position.y = 1.05; head.castShadow = true;
  tarsiusBody.add(head);
  // leaf hat (tiny guardian of the forest)
  const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.5, 7),
    new THREE.MeshStandardMaterial({ color: 0x2d6a4f, roughness: 0.7, flatShading: true }));
  leaf.position.set(0.12, 1.78, 0); leaf.rotation.z = -0.35; leaf.castShadow = true;
  leaf.name = 'leafhat';
  tarsiusBody.add(leaf);
  // HUGE tarsius eyes
  const whiteM = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.15 });
  const pupM = new THREE.MeshStandardMaterial({ color: 0x20140a, roughness: 0.1 });
  eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.34, 20, 16), whiteM);
  eyeL.position.set(-0.32, 1.18, 0.55); eyeL.scale.z = 0.7;
  eyeR = eyeL.clone(); eyeR.position.x = 0.32;
  tarsiusBody.add(eyeL, eyeR);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12), pupM);
  pupilL.position.set(-0.32, 1.18, 0.76);
  const pupilR = pupilL.clone(); pupilR.position.x = 0.32;
  tarsiusBody.add(pupilL, pupilR);
  [eyeL, eyeR].forEach(e => {
    const hl = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffffff }));
    hl.position.set(e.position.x + 0.08, e.position.y + 0.1, e.position.z + 0.18);
    tarsiusBody.add(hl);
  });
  [-1, 1].forEach(s => {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.3, 14, 12), fur);
    ear.position.set(s * 0.62, 1.55, -0.05); ear.scale.set(1, 1.25, 0.35);
    ear.castShadow = true; ear.name = s < 0 ? 'earL' : 'earR';
    tarsiusBody.add(ear);
    const inner = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 10),
      new THREE.MeshStandardMaterial({ color: 0xe8b87d }));
    inner.position.set(s * 0.62, 1.55, 0.06); inner.scale.set(1, 1.25, 0.3);
    tarsiusBody.add(inner);
  });
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.16, 2.2, 12),
    new THREE.MeshStandardMaterial({ color: 0x6c4a2a, roughness: 0.7 }));
  pipe.rotation.x = Math.PI / 2; pipe.position.set(0, 0.55, 1.1); pipe.castShadow = true;
  tarsiusBody.add(pipe);
  muzzle = new THREE.Object3D(); muzzle.position.set(0, 0.55, 2.25);
  tarsiusBody.add(muzzle);
  flashMesh = new THREE.Mesh(new THREE.SphereGeometry(0.35, 12, 10),
    new THREE.MeshBasicMaterial({ color: 0xffe66d, transparent: true, opacity: 0 }));
  flashMesh.position.copy(muzzle.position);
  tarsiusBody.add(flashMesh);
  [-1, 1].forEach(s => {
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.7, 8), fur);
    arm.position.set(s * 0.45, 0.5, 0.75); arm.rotation.x = 1.1; arm.rotation.z = s * -0.5;
    arm.castShadow = true; tarsiusBody.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), fur);
    hand.position.set(s * 0.28, 0.55, 1.05); tarsiusBody.add(hand);
  });
  [-1, 1].forEach(s => {
    const foot = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 10), fur);
    foot.position.set(s * 0.45, -0.85, 0.35); foot.scale.set(0.7, 0.4, 1.5);
    tarsiusBody.add(foot);
  });
  const tailCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, -0.4, -0.7), new THREE.Vector3(0.6, -0.6, -1.4), new THREE.Vector3(1.3, 0.1, -1.7),
  ]);
  tailMesh = new THREE.Mesh(new THREE.TubeGeometry(tailCurve, 12, 0.09, 8),
    new THREE.MeshStandardMaterial({ color: 0x8a5a33 }));
  tarsiusBody.add(tailMesh);

  tarsius.position.copy(SHOOTER_POS);
  scene.add(tarsius);
}
function makeOrb(colorIdx) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.4, 20, 16),
    new THREE.MeshStandardMaterial({ color: PALETTE[colorIdx], roughness: 0.2, metalness: 0.1 }));
  m.castShadow = true;
  return m;
}
const curOrb = makeOrb(0); curOrb.position.set(0, 4.6, 1.0); scene.add(curOrb);
const nextOrb = makeOrb(1); nextOrb.scale.setScalar(0.65); nextOrb.position.set(1.3, 4.1, 1.0); scene.add(nextOrb);
const aimGeo = new THREE.BufferGeometry().setFromPoints(
  Array.from({ length: 8 }, (_, i) => new THREE.Vector3(0, 0, 2.6 + i * 0.9)));
const aimLine = new THREE.Points(aimGeo, new THREE.PointsMaterial({
  color: 0xffffff, size: 0.28, transparent: true, opacity: 0.85, sizeAttenuation: true }));
tarsiusBody.add(aimLine);

/* ==================== GAME STATE ==================== */
const ballGeo = new THREE.SphereGeometry(BALL_R, 24, 18);
const ballMats = PALETTE.map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.22, metalness: 0.08 }));
const hiGeo = new THREE.SphereGeometry(0.13, 8, 8);
const hiMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 });
const ringGeo = new THREE.TorusGeometry(0.62, 0.09, 8, 24);
const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
const trailGeo = new THREE.SphereGeometry(0.16, 8, 6);

function letterSprite(letter, bg) {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d');
  x.fillStyle = bg; x.beginPath(); x.arc(32, 32, 27, 0, 7); x.fill();
  x.lineWidth = 5; x.strokeStyle = '#fffdf4'; x.stroke();
  x.fillStyle = '#fff'; x.font = '900 32px "Trebuchet MS", sans-serif';
  x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(letter, 32, 34);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: false }));
  s.scale.set(0.9, 0.9, 1); s.renderOrder = 5;
  return s;
}
const G = {
  status: 'menu', paused: false, muted: false, diff: 'normal',
  sim: false, attract: false, attractThink: 0, attractEnd: 0,
  balls: [], projectiles: [], particles: [], rings: [],
  spawned: 0, destroyed: 0, score: 0, combo: 1, maxCombo: 1,
  streak: 0, bestStreak: 0, shots: 0, hits: 0, powersUsed: 0,
  aim: 0, time: 0, playTime: 0, introT: 0,
  cur: 0, nxt: 1, shootCD: 0, blink: 0, recoil: 0, happy: 0, flash: 0,
  slowT: 0, revT: 0, shake: 0, danger: false, heartT: 0,
  best: 0,
};
try { G.best = +(localStorage.getItem('gunbatte-balls-best') || 0); } catch { /* private mode */ }

const randColor = () => (Math.random() * COLORS_N) | 0;
const randPower = () => ['bomb', 'slow', 'rev'][(Math.random() * 3) | 0];
const pointAt = s => curve.getPointAt(THREE.MathUtils.clamp(s / curveLen, 0, 1));
const tangentAt = s => curve.getTangentAt(THREE.MathUtils.clamp(s / curveLen, 0, 1));

function makeBallMesh(color, power) {
  const mesh = new THREE.Group();
  const core = new THREE.Mesh(ballGeo, ballMats[color]);
  core.castShadow = true;
  const hi = new THREE.Mesh(hiGeo, hiMat);
  hi.position.set(-0.18, 0.2, 0.35);
  mesh.add(core, hi);
  if (power) {
    const r = new THREE.Mesh(ringGeo, ringMat);
    r.rotation.x = Math.PI / 2.3;
    mesh.add(r);
    const sp = letterSprite(POWERS[power].letter, POWERS[power].bg);
    sp.position.y = 1.0;
    mesh.add(sp);
  }
  return mesh;
}
function spawnBall(s = 0, color = randColor(), power = null) {
  const mesh = makeBallMesh(color, power);
  const p = pointAt(s); mesh.position.copy(p); mesh.position.y = 1.05;
  scene.add(mesh);
  G.balls.push({ s, color, power, mesh, core: mesh.children[0] });
  G.balls.sort((a, b) => b.s - a.s);
}

/* ---------- HUD / feedback ---------- */
const $ = id => document.getElementById(id);
function updateHUD() {
  if (G.sim) return;
  $('score').textContent = G.score;
  $('progress-bar').style.width = `${Math.min(100, (G.destroyed / TOTAL_BALLS) * 100)}%`;
  $('progress-text').textContent = `${G.destroyed}/${TOTAL_BALLS} popped • ${G.balls.length} on island`;
  $('cur-ball').style.background = PALETTE_CSS[G.cur];
  $('next-ball').style.background = PALETTE_CSS[G.nxt];
  curOrb.material = ballMats[G.cur]; nextOrb.material = ballMats[G.nxt];
  const cb = $('combo');
  if (G.combo >= 2 && G.status === 'playing') {
    cb.classList.remove('hidden');
    const b = cb.querySelector('b'); if (b) b.textContent = '×' + G.combo;
    else cb.innerHTML = `COMBO <b>×${G.combo}</b>`;
  } else cb.classList.add('hidden');
  $('badge-slow').classList.toggle('hidden', !(G.slowT > 0));
  $('badge-rev').classList.toggle('hidden', !(G.revT > 0));
  if (G.slowT > 0) $('badge-slow').querySelector('.bar div').style.width = `${(G.slowT / 8) * 100}%`;
  if (G.revT > 0) $('badge-rev').querySelector('.bar div').style.width = `${(G.revT / 6) * 100}%`;
  $('danger').classList.toggle('active', G.danger && G.status === 'playing');
}
function bumpScore() {
  if (G.sim) return;
  const el = $('score');
  el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
}
function floater(text, worldPos, big = false) {
  if (G.sim) return;
  const v = worldPos.clone().project(camera);
  const el = document.createElement('div');
  el.className = 'float' + (big ? ' big' : '');
  el.textContent = text;
  el.style.left = `${(v.x * 0.5 + 0.5) * innerWidth}px`;
  el.style.top = `${(-v.y * 0.5 + 0.5) * innerHeight}px`;
  el.addEventListener('animationend', () => el.remove());
  $('floaters').appendChild(el);
  setTimeout(() => el.remove(), 1200);
}
let bannerTimer = null;
function showBanner(main, sub = '', ms = 2000) {
  if (G.sim) return;
  const b = $('banner');
  $('banner-main').textContent = main;
  $('banner-sub').textContent = sub;
  b.classList.remove('hidden', 'show'); void b.offsetWidth; b.classList.add('show');
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add('hidden'), ms);
}
function burst(pos, colorIdx, n = 14, spread = 8) {
  if (G.sim) return;
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.12 + Math.random() * 0.12, 8, 6),
      new THREE.MeshBasicMaterial({ color: i % 3 ? PALETTE[colorIdx] : 0xffffff }));
    m.position.copy(pos);
    const v = new THREE.Vector3((Math.random() - 0.5) * spread, Math.random() * 7 + 2, (Math.random() - 0.5) * spread);
    G.particles.push({ m, v, life: 0.7 + Math.random() * 0.4 });
    scene.add(m);
  }
}
function shockwave(pos, color = 0xffffff, max = 4) {
  if (G.sim) return;
  const m = new THREE.Mesh(new THREE.RingGeometry(0.5, 0.72, 32),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, side: THREE.DoubleSide }));
  m.rotation.x = -Math.PI / 2; m.position.copy(pos); m.position.y = 1.0;
  scene.add(m);
  G.rings.push({ m, t: 0, max });
}

/* ---------- powers ---------- */
function triggerPower(type, pos) {
  G.powersUsed++;
  const label = POWERS[type].name;
  if (type === 'bomb') {
    burst(pos, 0, 26, 12); burst(pos, 3, 18, 12);
    shockwave(pos, 0xff9e00, 5);
    G.shake = Math.min(1.4, G.shake + 1.0);
    sfx('bomb');
    floater('BOOM!', pos, true);
    const victims = G.balls.filter(b => b.mesh.position.distanceTo(pos) < 5.5).slice(0, 12);
    victims.forEach(v => {
      const i = G.balls.indexOf(v);
      if (i >= 0) {
        burst(v.mesh.position, v.color, 8, 7);
        scene.remove(v.mesh); G.balls.splice(i, 1);
        G.destroyed++; G.score += 15;
      }
    });
    G.score += 10;
  } else if (type === 'slow') {
    G.slowT = 8; sfx('power');
    shockwave(pos, 0x4cc9f0, 4);
    burst(pos, 1, 16, 7);
    showBanner('CHILLSEED!', 'the march slows…');
    floater('+SLOW', pos, true);
  } else if (type === 'rev') {
    G.revT = 6; sfx('power');
    shockwave(pos, 0xf72585, 4);
    burst(pos, 2, 16, 7);
    showBanner('REWINDSEED!', 'time rolls back…');
    floater('+REWIND', pos, true);
  }
  bumpScore(); updateHUD(); checkWin();
}

/* ---------- match / insert / shoot ---------- */
function popCheck(startIdx) {
  const b = G.balls;
  if (!b[startIdx]) return false;
  const c = b[startIdx].color;
  let lo = startIdx, hi = startIdx;
  while (lo - 1 >= 0 && b[lo - 1].color === c && (b[lo - 1].s - b[lo].s) < SPACING * 1.6) lo--;
  while (hi + 1 < b.length && b[hi + 1].color === c && (b[hi].s - b[hi + 1].s) < SPACING * 1.6) hi++;
  const n = hi - lo + 1;
  if (n >= 3) {
    const mid = b[lo].mesh.position.clone();
    const removed = b.slice(lo, hi + 1);
    for (let i = hi; i >= lo; i--) { scene.remove(b[i].mesh); b.splice(i, 1); }
    burst(mid, c, n >= 4 ? 24 : 14, n >= 4 ? 11 : 8);
    if (n >= 4) { shockwave(mid, PALETTE[c], 3.5); G.shake = Math.min(1, G.shake + 0.35); }
    const gained = n * 10 * G.combo;
    G.score += gained; G.destroyed += n;
    floater(`+${gained}`, mid, n >= 4);
    if (G.combo >= 2) floater(`COMBO ×${G.combo}`, mid.clone().add(new THREE.Vector3(0, 1, 0)));
    G.combo++; G.maxCombo = Math.max(G.maxCombo, G.combo);
    G.happy = 0.7;
    sfx(n >= 4 ? 'big' : 'pop');
    removed.forEach(r => { if (r.power) triggerPower(r.power, r.mesh.position); });
    bumpScore(); updateHUD(); checkWin();
    return true;
  }
  return false;
}
function checkWin() {
  if (G.status === 'playing' && G.spawned >= TOTAL_BALLS && G.balls.length === 0) endGame(true);
}
function shoot() {
  if (G.status !== 'playing' || G.shootCD > 0 || G.paused) return;
  G.shootCD = 0.22;
  const dir = new THREE.Vector3(Math.sin(G.aim), 0, Math.cos(G.aim));
  const mp = new THREE.Vector3(); muzzle.getWorldPosition(mp);
  const mesh = makeBallMesh(G.cur, null);
  mesh.position.copy(mp);
  scene.add(mesh);
  const trail = [];
  for (let i = 0; i < 4; i++) {
    const t = new THREE.Mesh(trailGeo, new THREE.MeshBasicMaterial({
      color: PALETTE[G.cur], transparent: true, opacity: 0.5 - i * 0.11 }));
    scene.add(t); trail.push(t);
  }
  G.projectiles.push({ color: G.cur, pos: mp.clone(), vel: dir.multiplyScalar(26), mesh, core: mesh.children[0], trail, hist: [] });
  G.recoil = 1; G.flash = 0.09;
  G.shots++;
  sfx('shoot');
  G.cur = G.nxt; G.nxt = randColor();
  updateHUD();
}
function insertShot(proj, hitIdx) {
  const b = G.balls;
  const hit = b[hitIdx];
  // power seed: direct hit triggers it (any color), no insert
  if (hit.power) {
    const hp = hit.mesh.position.clone(), pw = hit.power;
    burst(hp, hit.color, 10, 7);
    scene.remove(hit.mesh); b.splice(hitIdx, 1);
    G.destroyed++; G.score += 5;
    floater('+5', hp);
    triggerPower(pw, hp);
    G.hits++; G.streak++; G.bestStreak = Math.max(G.bestStreak, G.streak);
    return;
  }
  const tangent = tangentAt(hit.s);
  const toHit = proj.pos.clone().sub(hit.mesh.position);
  const ahead = toHit.dot(tangent) > 0;
  const idx = ahead ? hitIdx : hitIdx + 1;
  let ns;
  if (idx === 0) ns = b[0].s + SPACING;
  else if (idx >= b.length) ns = b[b.length - 1].s - SPACING;
  else ns = (b[idx - 1].s + b[idx].s) / 2;
  const mesh = makeBallMesh(proj.color, null);
  const p = pointAt(ns); mesh.position.copy(p); mesh.position.y = 1.05;
  scene.add(mesh);
  b.splice(idx, 0, { s: ns, color: proj.color, power: null, mesh, core: mesh.children[0] });
  for (let i = idx + 1; i < b.length; i++) {
    const want = b[i - 1].s - SPACING;
    if (b[i].s > want) b[i].s = want;
  }
  G.hits++; G.streak++; G.bestStreak = Math.max(G.bestStreak, G.streak);
  if (G.streak > 0 && G.streak % 5 === 0) {
    G.score += G.streak * 5;
    floater(`STREAK ×${G.streak}!`, mesh.position.clone(), true);
    sfx('power');
  }
  updateHUD();
  if (!popCheck(idx)) { G.combo = 1; updateHUD(); }
}
function onMiss() {
  if (G.streak >= 3) floater('miss…', new THREE.Vector3(SHOOTER_POS.x, 3, SHOOTER_POS.z));
  G.streak = 0; G.combo = 1; updateHUD();
}

/* ---------- flow ---------- */
function bestSave() {
  if (G.score > G.best) {
    G.best = G.score;
    try { localStorage.setItem('gunbatte-balls-best', String(G.best)); } catch { /* ignore */ }
  }
}
function endGame(win) {
  if (G.status !== 'playing') return;
  G.status = win ? 'won' : 'lost';
  G.danger = false; updateHUD();
  bestSave();
  if (G.sim) return;
  if (G.attract) G.attractEnd = 4; // auto-restart countdown for demo mode
  const ov = $('end-overlay');
  ov.classList.remove('hidden');
  if (win) {
    const stars = 1 + (G.score >= 800 ? 1 : 0) + (G.score >= 1300 ? 1 : 0);
    $('end-title').textContent = '★ YOU WIN! ★';
    $('end-title').style.color = '#2d6a4f';
    $('end-stars').innerHTML = [1, 2, 3].map(i =>
      `<span class="${i <= stars ? '' : 'dim'}">★</span>`).join('');
    $('end-text').innerHTML = 'The island is safe! The tarsius does a happy wiggle.';
    const acc = G.shots ? Math.round((G.hits / G.shots) * 100) : 100;
    const mm = `${(G.playTime / 60) | 0}:${String((G.playTime | 0) % 60).padStart(2, '0')}`;
    $('end-stats').innerHTML =
      `<div>SCORE<b>${G.score}</b></div><div>BEST<b>${G.best}</b></div>` +
      `<div>TIME<b>${mm}</b></div><div>MAX COMBO<b>×${G.maxCombo}</b></div>` +
      `<div>ACCURACY<b>${acc}%</b></div><div>SEEDS<b>${G.powersUsed}</b></div>`;
    sfx('win');
  } else {
    $('end-title').textContent = '☠ SKULL CAVE HUNGRY…';
    $('end-title').style.color = '#9d0208';
    $('end-stars').innerHTML = '';
    $('end-text').innerHTML = `The marbles reached the skull…<br/><b>Score: ${G.score}</b> — try again, tiny guardian!`;
    $('end-stats').innerHTML =
      `<div>SCORE<b>${G.score}</b></div><div>POPPED<b>${G.destroyed}/${TOTAL_BALLS}</b></div>`;
    sfx('lose');
  }
}
function resetGame() {
  G.balls.forEach(x => scene.remove(x.mesh));
  G.projectiles.forEach(x => { scene.remove(x.mesh); x.trail.forEach(t => scene.remove(t)); });
  G.particles.forEach(x => scene.remove(x.m));
  G.rings.forEach(x => scene.remove(x.m));
  Object.assign(G, {
    balls: [], projectiles: [], particles: [], rings: [],
    spawned: 0, destroyed: 0, score: 0, combo: 1, maxCombo: 1,
    streak: 0, bestStreak: 0, shots: 0, hits: 0, powersUsed: 0,
    playTime: 0, shootCD: 0, slowT: 0, revT: 0, shake: 0,
    danger: false, heartT: 0, paused: false, introT: 1.8,
    status: 'intro', cur: randColor(), nxt: randColor(),
  });
  $('end-overlay').classList.add('hidden');
  $('pause-overlay').classList.add('hidden');
  for (let i = 0; i < 10; i++) spawnBall(14 - i * SPACING, randColor(), i === 5 ? 'bomb' : null);
  G.spawned = 10;
  showBanner('LEVEL 1', 'Koholint Island — defend the Skull Cave!');
  updateHUD();
}
function togglePause(force) {
  if (G.status !== 'playing' && G.status !== 'intro') return;
  const want = force !== undefined ? force : !G.paused;
  if (want === G.paused) return;
  G.paused = want;
  $('pause-overlay').classList.toggle('hidden', !want);
  sfx('click');
  if (AC) { if (want) AC.suspend(); else AC.resume(); }
}
function toggleMute() {
  G.muted = !G.muted;
  if (master) master.gain.value = G.muted ? 0 : 1;
  $('mute-btn').classList.toggle('off', G.muted);
}

/* ---------- input ---------- */
const ray = new THREE.Raycaster();
const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.6);
const mouseNDC = new THREE.Vector2();
addEventListener('pointermove', e => {
  mouseNDC.set((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
  ray.setFromCamera(mouseNDC, camera);
  const pt = new THREE.Vector3();
  if (ray.ray.intersectPlane(groundPlane, pt)) {
    G.aim = Math.atan2(pt.x - SHOOTER_POS.x, pt.z - SHOOTER_POS.z);
  }
});
addEventListener('pointerdown', e => {
  if (e.target.closest('button') || e.target.closest('.card')) return;
  audio();
  if (e.button === 2) {
    if (G.status !== 'playing') return;
    const t = G.cur; G.cur = G.nxt; G.nxt = t; sfx('swap'); updateHUD(); return;
  }
  shoot();
});
addEventListener('contextmenu', e => e.preventDefault());
addEventListener('keydown', e => {
  if (e.code === 'Space') {
    e.preventDefault();
    if (G.status !== 'playing' || G.paused) return;
    const t = G.cur; G.cur = G.nxt; G.nxt = t; sfx('swap'); updateHUD();
  } else if (e.code === 'KeyP' || e.code === 'Escape') togglePause();
  else if (e.code === 'KeyM') toggleMute();
});
$('start-btn').onclick = () => {
  audio(); if (AC && AC.state === 'suspended') AC.resume();
  $('overlay').classList.add('hidden');
  resetGame(); Music.start();
  try { $('best-line').textContent = 'best: ' + G.best; } catch { /* ignore */ }
};
document.querySelectorAll('.diff-btn').forEach(btn => {
  btn.onclick = () => {
    G.diff = btn.dataset.diff;
    document.querySelectorAll('.diff-btn').forEach(x => x.classList.toggle('sel', x === btn));
    sfx('click');
  };
});
$('restart-btn').onclick = () => { sfx('click'); resetGame(); };
$('restart-btn2').onclick = () => { sfx('click'); togglePause(false); resetGame(); };
$('resume-btn').onclick = () => togglePause(false);
$('pause-btn').onclick = () => togglePause();
$('mute-btn').onclick = () => { audio(); toggleMute(); sfx('click'); };
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
try { $('best-line').textContent = 'best: ' + G.best; } catch { /* ignore */ }

/* ==================== AUTOPILOT + SIMULATOR + ATTRACT ====================
   botThink plays like a person: picks a target every `interval` seconds,
   leads the moving chain, aims with gaussian wobble, swaps when the next
   seed fits better, and snipes power seeds. Used by attract mode AND by the
   headless balance simulator (test/sim.mjs), which runs step() with no
   rendering to play whole games in seconds. */
const ATTRACT_SKILL = { interval: 0.5, noise: 0.02, snipe: 0.8, swap: true };
function botThink(skill = ATTRACT_SKILL) {
  if (G.status !== 'playing' || G.paused || !G.balls.length) return;
  const b = G.balls;
  let target = null;
  // 1) snipe urgent power seeds (any color triggers)
  for (const x of b) {
    if (x.power && x.s / curveLen > 0.12 && Math.random() < (skill.snipe ?? 0.7)) { target = x; break; }
  }
  // 2) held color, closest to the skull
  if (!target) {
    let bestS = -1;
    for (const x of b) if (x.color === G.cur && x.s > bestS) bestS = x.s;
    if (bestS >= 0) target = b.find(x => x.color === G.cur && x.s === bestS);
    else if (skill.swap !== false) {
      let bs2 = -1;
      for (const x of b) if (x.color === G.nxt && x.s > bs2) bs2 = x.s;
      if (bs2 >= 0) {
        const t = G.cur; G.cur = G.nxt; G.nxt = t;
        if (!G.sim) updateHUD();
        target = b.find(x => x.color === G.cur && x.s === bs2);
      }
    }
    if (!target) {
      if (skill.patient && b[0].s / curveLen < 0.25) return; // hold fire: nothing matches yet, skull is far
      target = b[0]; // dump at the head, like an impatient human
    }
  }
  // 3) lead the moving chain + human aim wobble
  const spd = baseSpeed() * (G.slowT > 0 ? 0.45 : 1) * (G.revT > 0 ? -0.85 : 1);
  const tp = target.mesh.position;
  const dist = Math.hypot(tp.x - SHOOTER_POS.x, tp.z - SHOOTER_POS.z);
  const p = pointAt(target.s + THREE.MathUtils.clamp(spd * (dist / 26), -3, 6));
  const wobble = (Math.random() + Math.random() - 1) * (skill.noise ?? 0.025);
  G.aim = Math.atan2(p.x - SHOOTER_POS.x, p.z - SHOOTER_POS.z) + wobble;
  tarsius.rotation.y = G.aim;
  G.shootCD = 0;
  shoot();
}
function simCleanupToMenu() {
  G.balls.forEach(x => scene.remove(x.mesh));
  G.projectiles.forEach(x => { scene.remove(x.mesh); x.trail.forEach(t => scene.remove(t)); });
  G.particles.forEach(x => scene.remove(x.m));
  G.rings.forEach(x => scene.remove(x.m));
  Object.assign(G, {
    status: 'menu', paused: false, balls: [], projectiles: [], particles: [], rings: [],
    spawned: 0, destroyed: 0, score: 0, combo: 1, maxCombo: 1, streak: 0,
    shots: 0, hits: 0, powersUsed: 0, playTime: 0, slowT: 0, revT: 0,
    danger: false, heartT: 0, shootCD: 0, sim: false,
  });
  $('end-overlay').classList.add('hidden');
  $('overlay').classList.remove('hidden');
  updateHUD();
}
/* Play one full game headlessly at 30 steps/sec. Returns a result summary. */
function simGame(skill, diff = 'normal', maxMin = 12) {
  G.diff = diff;
  G.sim = true;
  const wasMuted = G.muted; G.muted = true;
  $('overlay').classList.add('hidden');
  resetGame();
  const dt = 1 / 30;
  let t = 0, nextThink = 1.9, guard = 0;
  const cap = maxMin * 60;
  while ((G.status === 'intro' || G.status === 'playing') && t < cap && ++guard < 50000) {
    step(dt, dt);
    t += dt;
    if (G.status === 'playing' && t >= nextThink) {
      botThink(skill);
      nextThink = t + skill.interval * (0.7 + Math.random() * 0.6);
    }
  }
  const res = {
    win: G.status === 'won', diff, score: G.score, des: G.destroyed,
    time: Math.round(G.playTime), shots: G.shots,
    acc: G.shots ? Math.round((G.hits / G.shots) * 100) : 100,
    maxCombo: G.maxCombo, bestStreak: G.bestStreak, powers: G.powersUsed,
    timeout: t >= cap,
  };
  G.muted = wasMuted;
  simCleanupToMenu();
  return res;
}
function simGames(n, skill, diff = 'normal') {
  const out = [];
  for (let i = 0; i < n; i++) {
    const r = simGame(skill, diff);
    out.push(r);
    console.log(`[sim] ${diff} game ${i + 1}/${n}: ${r.win ? 'WIN' : 'LOSE'} score=${r.score} des=${r.des} time=${r.time}s acc=${r.acc}%`);
  }
  return out;
}
/* ---------- attract mode: self-playing demo for the trailer ---------- */
function startAttract() {
  G.attract = true;
  G.muted = true;
  $('mute-btn').classList.add('off');
  $('overlay').classList.add('hidden');
  $('end-overlay').classList.add('hidden');
  resetGame();
  G.attractThink = 1.2;
}

/* ==================== MAIN LOOP ==================== */
const clockLast = { t: performance.now() };
let spawnAcc = 0;
const tmpAxis = new THREE.Vector3();
function tick() {
  requestAnimationFrame(tick);
  const nowT = performance.now();
  const rawDt = Math.min((nowT - clockLast.t) / 1000, 0.05);
  clockLast.t = nowT;
  const dt = G.paused ? 0 : rawDt;
  G.time += dt;
  if (G.shootCD > 0) G.shootCD -= dt;
  Music.tick();

  /* --- ambient life (always, even in menu) --- */
  clouds.forEach(c => { c.g.position.y = c.y0 + Math.sin(G.time * 0.8 + c.ph) * 0.5; });
  const f1 = scene.getObjectByName('foam1'), f2 = scene.getObjectByName('foam2');
  if (f1) f1.scale.setScalar(1 + Math.sin(G.time * 1.4) * 0.02);
  if (f2) { const s = 1 + Math.sin(G.time * 1.4 + 2) * 0.04; f2.scale.setScalar(s); }
  // water waves
  {
    const pos = waterMesh.geometry.attributes.position;
    const arr = pos.array;
    for (let i = 0; i < pos.count; i++) {
      const x = waterBase[i * 3], y = waterBase[i * 3 + 1];
      arr[i * 3 + 2] = Math.sin(x * 0.12 + G.time * 1.6) * 0.2 + Math.cos(y * 0.15 + G.time * 1.1) * 0.18;
    }
    pos.needsUpdate = true;
    waterMesh.geometry.computeVertexNormals();
  }
  pinwheels.forEach((h, i) => { h.rotation.z += dt * (6 + i * 2); });
  butterflies.forEach(bf => {
    const t = G.time * 0.7 + bf.ph;
    bf.g.position.set(bf.cx + Math.sin(t) * 3, 2.4 + Math.sin(t * 2.3) * 0.5, bf.cz + Math.cos(t * 0.8) * 3);
    bf.g.rotation.y = Math.atan2(Math.cos(t) * 3, -Math.sin(t * 0.8) * 2.4);
    const flap = Math.sin(G.time * 22 + bf.ph) * 0.85;
    bf.L.rotation.y = flap; bf.R.rotation.y = -flap;
  });
  // torch flicker
  {
    const fl = scene.getObjectByName('flame'), tl = scene.getObjectByName('torchlight');
    if (fl) { fl.scale.set(1 + Math.sin(G.time * 13) * 0.12, 1 + Math.sin(G.time * 17) * 0.18, 1); fl.rotation.y += dt * 3; }
    if (tl) tl.intensity = 6 + Math.sin(G.time * 13) * 1.2 + Math.sin(G.time * 31) * 0.8;
  }
  // skull smoke
  smokes.forEach(s => {
    s.userData.t += dt;
    if (s.userData.t > 3) {
      s.userData.t = 0;
      s.position.copy(skullPos).add(new THREE.Vector3(0.4 + (Math.random() - 0.5) * 1.5, 4.4, 0.5));
    }
    s.position.y += dt * 0.9;
    const k = s.userData.t / 3;
    s.scale.setScalar(0.6 + k * 1.6);
    s.material.opacity = 0.35 * (1 - k);
  });
  // skull eyes react to danger
  if (skullEyeMat) {
    const target = G.danger && (G.status === 'playing') ? 2.6 + Math.sin(G.time * 8) * 0.8 : 0.35;
    skullEyeMat.emissiveIntensity += (target - skullEyeMat.emissiveIntensity) * Math.min(1, dt * 5);
  }

  /* --- tarsius life --- */
  tarsius.rotation.y = G.aim;
  tarsiusBody.position.y = 1.0 + Math.sin(G.time * 3) * 0.05 - G.recoil * 0.15 + (G.happy > 0 ? Math.sin(G.happy * 12) * 0.12 : 0);
  tarsiusBody.rotation.x = G.recoil * 0.25;
  const squash = 1 + (G.happy > 0 ? Math.sin(G.happy * 12) * 0.06 : 0);
  tarsiusBody.scale.set(2 - squash > 0 ? 1 / Math.sqrt(squash) : 1, squash, 1);
  if (G.recoil > 0) G.recoil = Math.max(0, G.recoil - dt * 5);
  if (G.happy > 0) G.happy = Math.max(0, G.happy - dt);
  if (tailMesh) tailMesh.rotation.y = Math.sin(G.time * 2.2) * 0.35;
  const earL = tarsiusBody.getObjectByName('earL');
  if (earL) earL.rotation.z = Math.sin(G.time * 1.3) * 0.12 + (G.happy > 0 ? 0.35 : 0);
  G.blink -= dt;
  if (G.blink < -0.12) G.blink = 2 + Math.random() * 3;
  eyeL.scale.y = eyeR.scale.y = G.blink < 0 ? 0.1 : 1;
  if (G.flash > 0) {
    G.flash -= dt;
    flashMesh.material.opacity = Math.max(0, G.flash / 0.09) * 0.95;
    flashMesh.scale.setScalar(1 + (0.09 - Math.max(0, G.flash)) * 8);
  } else flashMesh.material.opacity = 0;
  curOrb.position.y = 4.6 + Math.sin(G.time * 2) * 0.15;
  nextOrb.position.y = 4.1 + Math.sin(G.time * 2 + 1) * 0.12;
  curOrb.rotation.y += dt; nextOrb.rotation.y -= dt * 1.4;

  /* --- camera (sway + shake) --- */
  if (G.shake > 0) G.shake = Math.max(0, G.shake - rawDt * 2.2);
  const shx = (Math.random() - 0.5) * G.shake * 0.9;
  const shy = (Math.random() - 0.5) * G.shake * 0.7;
  const drift = G.attract ? Math.sin(G.time * 0.05) * 2.5 : 0; // slow cinematic pan
  camera.position.set(Math.sin(G.time * 0.08) * 1.2 + shx + drift, 29 + shy, 21);
  camera.lookAt(0, 0, 1.0);

  step(dt, rawDt);
  // attract-mode self-play + auto-restart (trailer demo)
  if (G.attract && !G.paused) {
    if (G.status === 'playing') {
      G.attractThink -= rawDt;
      if (G.attractThink <= 0) { G.attractThink = 0.5; botThink(ATTRACT_SKILL); }
    } else if (G.status === 'won' || G.status === 'lost') {
      G.attractEnd -= rawDt;
      if (G.attractEnd <= 0) { $('end-overlay').classList.add('hidden'); resetGame(); }
    } else if (G.status === 'menu') {
      startAttract();
    }
  }
  renderer.render(scene, camera);
}

/* Pure game logic, shared by the live loop and the fast headless simulator:
   chain, spawner, projectiles, powers, particles. No rendering, no DOM in sim. */
function step(dt, rawDt) {
  if ((G.status === 'playing' || G.status === 'intro') && !G.paused) {
    if (G.status === 'intro') {
      G.introT -= dt;
      if (G.introT <= 0) { G.status = 'playing'; showBanner('GO!', 'match 3 or more!'); }
    } else {
      G.playTime += dt;
      if (G.slowT > 0) G.slowT -= dt;
      if (G.revT > 0) G.revT -= dt;
      const reversing = G.revT > 0;
      const spd = baseSpeed() * (G.slowT > 0 ? 0.45 : 1) * (reversing ? -0.85 : 1)
        * (G.danger && !reversing ? 0.85 : 1); // skull toys with its food: final-stand brake

      // spawner (every 7th marble carries a power seed)
      if (G.spawned < TOTAL_BALLS) {
        spawnAcc += dt;
        const tail = G.balls[G.balls.length - 1];
        const gapOk = !tail || tail.s > SPACING * 1.1;
        if (spawnAcc > (SPACING / Math.max(0.4, baseSpeed())) * 1.35 && gapOk) {
          spawnAcc = 0;
          const pw = (G.spawned % 7 === 6) ? randPower() : null;
          spawnBall(0, randColor(), pw);
          G.spawned++;
          if (pw) floater(POWERS[pw].name + '!', G.balls[G.balls.length - 1].mesh.position);
          updateHUD();
        }
      }
      // chain movement
      const b = G.balls;
      if (b.length) {
        b[0].s += spd * dt;
        for (let i = 1; i < b.length; i++) {
          const dist = b[i - 1].s - b[i].s;
          if (reversing) {
            // whole chain backs up, keep spacing
            b[i].s += spd * dt;
            if (b[i - 1].s - b[i].s < SPACING * 0.9) b[i].s = b[i - 1].s - SPACING * 0.9;
          } else if (dist > SPACING + 0.06) {
            b[i].s += Math.min(5.0 * dt, dist - SPACING); // magnet catch-up
          } else {
            b[i].s += spd * dt;
            if (b[i - 1].s - b[i].s < SPACING) b[i].s = b[i - 1].s - SPACING;
          }
          if (b[i].s < 0) b[i].s = 0;
        }
        b.forEach(x => {
          const p = pointAt(x.s);
          x.mesh.position.set(p.x, 1.05, p.z);
          // rolling
          tmpAxis.copy(tangentAt(x.s));
          const ax = new THREE.Vector3(-tmpAxis.z, 0, tmpAxis.x).normalize();
          x.core.rotateOnWorldAxis(ax, (spd * dt) / BALL_R);
        });
        const headR = b[0].s / curveLen;
        const wasDanger = G.danger;
        G.danger = headR > 0.72;
        if (G.danger && !wasDanger) {
          showBanner('THE SKULL STIRS!', 'hurry, little guardian!');
          sfx('warn');
        }
        if (G.danger) {
          G.heartT -= dt;
          if (G.heartT <= 0) { G.heartT = 1.6; sfx('heart'); }
        }
        if (!reversing && b[0].s >= curveLen - 1.2) endGame(false);
        updateHUD();
      }
      // projectiles
      for (let i = G.projectiles.length - 1; i >= 0; i--) {
        const pr = G.projectiles[i];
        pr.pos.addScaledVector(pr.vel, dt);
        pr.mesh.position.set(pr.pos.x, 1.05, pr.pos.z);
        pr.core.rotation.y += dt * 9;
        pr.hist.unshift(pr.pos.clone());
        if (pr.hist.length > 9) pr.hist.pop();
        pr.trail.forEach((t, k) => {
          const h = pr.hist[Math.min(pr.hist.length - 1, k * 2 + 1)];
          if (h) { t.position.set(h.x, 1.05, h.z); t.visible = true; }
          else t.visible = false;
        });
        let dead = Math.abs(pr.pos.x) > 20 || Math.abs(pr.pos.z) > 20;
        if (!dead) {
          // nearest-ball wins (fairer hits when crossing a moving chain)
          let bestJ = -1, bestD = Infinity;
          for (let j = 0; j < G.balls.length; j++) {
            const bp = G.balls[j].mesh.position;
            const dx = pr.pos.x - bp.x, dz = pr.pos.z - bp.z;
            const d2 = dx * dx + dz * dz;
            if (d2 < bestD) { bestD = d2; bestJ = j; }
          }
          if (bestJ >= 0 && bestD < (BALL_R * 2 - 0.06) ** 2) {
            const j = bestJ;
            scene.remove(pr.mesh); pr.trail.forEach(t => scene.remove(t));
            G.projectiles.splice(i, 1);
            insertShot(pr, j);
            dead = true;
          }
        }
        if (dead && G.projectiles[i] === pr) { /* hit: already spliced */ }
        else if (dead) {
          scene.remove(pr.mesh); pr.trail.forEach(t => scene.remove(t));
          G.projectiles.splice(i, 1);
          onMiss();
        }
      }
    }
    // particles + rings always animate (even intro)
    for (let i = G.particles.length - 1; i >= 0; i--) {
      const p = G.particles[i];
      p.life -= dt; p.v.y -= 14 * dt;
      p.m.position.addScaledVector(p.v, dt);
      p.m.scale.setScalar(Math.max(0.01, p.life * 1.5));
      if (p.life <= 0) { scene.remove(p.m); G.particles.splice(i, 1); }
    }
    for (let i = G.rings.length - 1; i >= 0; i--) {
      const r = G.rings[i];
      r.t += dt * 2.2;
      r.m.scale.setScalar(1 + r.t * r.max);
      r.m.material.opacity = 0.9 * (1 - r.t);
      if (r.t >= 1) { scene.remove(r.m); G.rings.splice(i, 1); }
    }
  }
}
updateHUD();
tick();

/* ---------- hooks for automated verification ---------- */
window.__game = {
  G, curveLen, PALETTE_CSS, ballMats, spawnBall, pointAt, triggerPower,
  scene, camera, TOTAL_BALLS, DIFFS, ATTRACT_SKILL, botThink, simGame, simGames,
  start: () => { $('overlay').classList.add('hidden'); resetGame(); Music.start(); },
  shootAt: (x, z) => {
    G.aim = Math.atan2(x - SHOOTER_POS.x, z - SHOOTER_POS.z);
    tarsius.rotation.y = G.aim;
    G.shootCD = 0; shoot();
  },
  ballCount: () => G.balls.length,
  score: () => G.score,
  status: () => G.paused ? 'paused' : G.status,
};
/* ---------- attract mode via ?attract=1 (self-playing trailer demo) ---------- */
try {
  if (new URLSearchParams(location.search).has('attract')) startAttract();
} catch { /* ignore */ }
